package br.com.fr.commons.util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Romeu Franzoia Jr
 */
public class MaoUtil {
    
    private static MaoUtil instance;
    
    public static MaoUtil getInstance() {
        if (instance == null) {
            instance = new MaoUtil();
        }
        return instance;
    }
    
    private MaoUtil() {
    }
    
    public List<Dedo> createDedosMaoE() {
        List<Dedo> lst = new ArrayList<>();
        
        lst.add(new Dedo(1));
        lst.add(new Dedo(2));
        lst.add(new Dedo(3));
        lst.add(new Dedo(4));
        lst.add(new Dedo(5));
        
        return lst;
    }
    
    public List<Dedo> createDedosMaoD() {
        
        List<Dedo> lst = new ArrayList<>();
        
        lst.add(new Dedo(6));
        lst.add(new Dedo(7));
        lst.add(new Dedo(8));
        lst.add(new Dedo(9));
        lst.add(new Dedo(10));
        
        return lst;
    }
    
	public String getNomeDedoById(int id) {
		return Arrays.asList("Mindinho Esquerdo (1)", "Anelar Esquerdo (2)", "M�dio Esquerdo (3)", "Indicador Esquerdo (4)", "Polegar Esquerdo (5)",
				"Polegar Direito (6)", "Indicador Direito (7)", "M�dio Direito (8)", "Anelar Direito (9)", "Mindinho Direito (10)").get(id - 1);
	}
}
