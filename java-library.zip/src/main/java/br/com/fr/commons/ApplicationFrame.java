/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fr.commons;

/**
 *
 * @author Romeu Franzoia Jr
 */
public interface ApplicationFrame {
 
}
