package br.com.fr.commons.util;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Romeu Franzoia Jr
 */
public class Maos {

    private HandCanvas maoE;
    private HandCanvas maoD;

    private List<Dedo> dedos;
    private List<TemplateData> templates;
            
    public Maos() {
        this(null);
    }
    
    public Maos(List<TemplateData> templates) {
        this.templates = templates;
        
        dedos = new ArrayList<>();

        maoE = new HandCanvas(HandCanvas.Direcao.Esquerda);
        maoE.setDedos(createDedosMaoE());
        
        maoD = new HandCanvas(HandCanvas.Direcao.Direita);
        maoD.setDedos(createDedosMaoD());

    }

    public HandCanvas getMaoE() {
        return maoE;
    }

    public HandCanvas getMaoD() {
        return maoD;
    }

    public List<Dedo> getDedos() {
        return dedos;
    }

    private List<Dedo> createDedosMaoE() {
        List<Dedo> lst = MaoUtil.getInstance().createDedosMaoE();

        if (templates != null) {
            for (TemplateData td : templates) {
                if (td.getId() <= 5) {
                    for (Dedo d : lst) {
                        if (d.getNumDedo() == td.getId()) {
                            
                            if (td.getImagem() != null) {
                                d.setImagemDigital(td.getImagem());
                            }
                            
                            if (td.getTemplate() != null) {
                                d.setCodigoValidacao(td.getTemplate().getData());
                            }

                            d.setSituacao(td.getStatus());
                            break;
                        }
                    }
                }
            }
        } else {
            int num = 1;
            for (Dedo d : lst) {
                d.setNumDedo(num++);
                d.setImagemDigital(null);
                d.setCodigoValidacao(null);
                d.setSituacao(ConstantesBiometria.ST_CAPTURA_NAO_CAPTURADO);
            }
        }
        
        dedos.addAll(lst);

        return lst;
    }

    private List<Dedo> createDedosMaoD() {

        List<Dedo> lst = MaoUtil.getInstance().createDedosMaoD();

        if (templates != null) {
            for (TemplateData td : templates) {
                if (td.getId() > 5) {
                    for (Dedo d : lst) {
                        if (d.getNumDedo() == td.getId()) {
                            if (td.getImagem() != null) {
                                d.setImagemDigital(td.getImagem());
                            }
                            
                            if (td.getTemplate() != null) {
                                d.setCodigoValidacao(td.getTemplate().getData());
                            }
                            d.setSituacao(td.getStatus());
                            break;
                        }
                    }
                }
            }
        } else {
            int num = 6;
            for (Dedo d : lst) {
                d.setNumDedo(num++);
                d.setImagemDigital(null);
                d.setCodigoValidacao(null);
                d.setSituacao(ConstantesBiometria.ST_CAPTURA_NAO_CAPTURADO);
            }
        }
        
        dedos.addAll(lst);

        return lst;
    }
}
