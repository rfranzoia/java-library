package br.com.fr.commons;

public enum MaskType {
    digit, upper, lower;
}