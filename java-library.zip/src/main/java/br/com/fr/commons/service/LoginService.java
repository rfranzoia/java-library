/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fr.commons.service;

import br.com.fr.commons.UsuarioLogin;
import br.com.fr.commons.exception.LoginInvalidoException;
import br.com.fr.commons.exception.PerfilInvalidoException;
import org.apache.log4j.Logger;

/**
 *
 * @author Romeu Franzoia Jr
 */
public class LoginService {
    
    public static final String URL_WS_LOGIN = "/security/login";
    
    private Logger logger = Logger.getLogger(getClass());
    private static LoginService instance;
    private UsuarioLogin currentUser = null;
    
    public static LoginService getInstance() {
        if (instance == null) {
            instance = new LoginService();
        }

        return instance;
    }

    private LoginService() {
    }

    public UsuarioLogin loginUsuarioSenha(UsuarioLogin usuarioLogin) throws LoginInvalidoException, PerfilInvalidoException, Exception {
        
        usuarioLogin = WSService.sendAndReceiveClassByURL(ApplicationUpdateService.getInstance().getDefaultWebServer() + URL_WS_LOGIN, usuarioLogin, UsuarioLogin.class);

        if (usuarioLogin.getNome() == null) {
            throw new LoginInvalidoException();
        }

        if (usuarioLogin.getPerfil() == null) {
            logger.error("Perfil Inválido!");
            throw new PerfilInvalidoException();
        }

        return usuarioLogin;
    }
    
    public UsuarioLogin getCurrentUser() {
        return this.currentUser;
    }
    
    public void setCurrentUser(UsuarioLogin usuarioLogin) {
        this.currentUser = usuarioLogin;
    }
}
