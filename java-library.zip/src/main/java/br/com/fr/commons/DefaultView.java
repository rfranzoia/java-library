/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fr.commons;

import javax.swing.JFrame;

/**
 *
 * @author Romeu Franzoia Jr
 */
public interface DefaultView {
    public void init(JFrame mainFrame);
    public void show();
    public void hide();
}
